---
title: Style Guide
type: note
tags: [mha-rpg/design]
status: evergreen
created: 2026-11-28
updated: 2026-11-28
summary: "Pixel style rules and Bailey's three reference pictures"
---

# Style Guide

Full text and the three reference pictures live in the repo: `games/style-guide/STYLE_GUIDE.md` and `games/style-guide/references/`.

**References:** a muscular pixel hero on a dusk street · a daytime pixel city street · the painted isometric records office.

**Rules in short**
1. One pixel grid: character and background share the same pixel size.
2. Hard pixels only: no blur, no smooth gradients.
3. Limited palette with 3-5 tone ramps per colour.
4. Warm highlights, cool shadows (hue-shifted shading).
5. Dither for gradients.
6. Dark outline on characters.
7. Body first, clothes second (separate layers).
8. Judge side by side with the references, big and clear.

Inside any one picture, everything shares one style.

Back to [[MHA RPG - Home]] · Plan: [[Pixel Hero Plan]]
